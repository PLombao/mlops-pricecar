from setuptools import setup, find_packages
from modelbuilder.version import __version__
import os

# Readme
with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'README.md'), encoding='utf-8') as f:
    readme = f.read()


# Version
VERSION = __version__

setup(
    name="modelbuilder",
    version=VERSION,
    url="https://github.com/PLombao/modelbuilder",
    author="Pablo Lombao",
    author_email="p.lombao@finsa.es",
    description="Trainer helpers to train machine learning models.",
    long_description=readme,
    long_description_content_type="text/markdown",
    packages=find_packages(exclude=['test']),
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    setup_requires=['setuptools>=38.6.0'],
    python_requires='>=3.6',
)