####### HEADER TO CONFIGURE LOGS ########
import logging
log = logging.getLogger(__name__)
##########################################

from typing import Literal, Tuple
import numpy as np
import pandas as pd
from scipy import stats
from modelbuilder.dataset import Dataset

class ConfidenceInterval:
    """
    Clase estandar de comportamiento de un objeto ConfidenceInterval
    """
    
    def fit(self, dataset: Dataset) -> None:
        self.dataset = dataset
        self.train_err = self.dataset.get_y() - self.dataset.data["prediction_train"]

    def transform(self, model_input: Dataset, base_error: float) -> Tuple[np.ndarray, np.ndarray]:
        # Cálculo ci
        ci = base_error

        # Cálculo ci_min y ci_max
        predictions = model_input.data["prediction"].to_numpy()
        ci_min = predictions - ci
        ci_max = predictions + ci
        return ci_min, ci_max

class ConfidenceIntervalLineal(ConfidenceInterval):
    """
    Subclase ConfidenceInterval basada en intervalo de confianza de un modelo lineal.

    Solo valido para modelos de tipo Linear Regression.
    """

    def __init__(self):
        # Intervalo de prediccion al 95% de confianza unilateral
        self.conf_interval = 0.95

    def transform(self, model_input: Dataset, base_error:float) -> Tuple[np.ndarray, np.ndarray]:
        train_x = self.dataset.get_x()

        # Matriz de diseño x_mat
        x_mat = np.column_stack((np.ones(len(train_x)), train_x))

        # Registro (o matriz de registros) a predecir
        x_mat_new = np.array(model_input.get_x())
        if x_mat_new.ndim==1:
            x_mat_new = x_mat_new.reshape((1,len(x_mat_new)))
        x_mat_new = np.column_stack((np.ones(x_mat_new.shape[0]), x_mat_new))

        # Calcular estimador de la varianza
        sigma2_est = sum(np.array(self.train_err)**2) / (x_mat.shape[0])

        # Calculo anchura intervalo de confianza
        inv = np.linalg.inv(np.dot(np.transpose(x_mat), x_mat))
        y_pred_se = np.dot(np.dot(x_mat_new, inv), np.transpose(x_mat_new))
        y_pred_se = np.identity(len(x_mat_new)) + y_pred_se
        ci = stats.norm.ppf(self.conf_interval)*np.sqrt(np.diag(sigma2_est * y_pred_se))

        # Cálculo ci_min y ci_max
        predictions = model_input.data["prediction"].to_numpy()
        ci_min = predictions - ci
        ci_max = predictions + ci
        return ci_min, ci_max

class ConfidenceIntervalEnsemble(ConfidenceInterval):
    """
    Subclase ConfidenceInterval calculado segun el acierto del modelo (error del modelo)
    y la diferencia entre modelos del ensemble (std de las predicciones unitarias)
    ci = sqrt(err**2 + std(modelos)**2)
    """

    def fit(self, dataset: Dataset) -> None:
        super().fit(dataset)
        self.sigma2 = (self.train_err ** 2).mean()
        # almacenando error de entrenamiento por calidad
        try:
            self.sigma2_calidad = pd.concat([self.dataset.data.calidad,
                                            self.train_err ** 2], axis=1).groupby("calidad").mean().iloc[:,0]
        except:
            log.warning("Error obteniendo sigma2_calidad durante entrenamiento.")

    def transform(self, model_input: Dataset, base_error: float) -> Tuple[np.ndarray, np.ndarray]:
        # recuperando predicciones individuales de los modelos en el ensemble
        pred_cols = [col for col in model_input.columns.predictions if col[:11]=="prediction_"]
        pred_partials = model_input.data[pred_cols]

        # Calculo anchura intervalo de confianza
        try:
            ci = np.sqrt(model_input.data.calidad.map(self.sigma2_calidad).fillna(self.sigma2) + (pred_partials.std(axis=1)*2)**2)
        except:
            log.warning("Error aplicando sigma2_calidad.")
            if hasattr(self, "sigma2"):
                ci = np.sqrt(self.sigma2 + (pred_partials.std(axis=1)*2)**2)
            else:
                ci = np.sqrt(base_error**2 + (pred_partials.std(axis=1)*2)**2)

        # Cálculo ci_min y ci_max
        predictions = model_input.data["prediction"].to_numpy()
        ci_min = predictions - ci
        ci_max = predictions + ci
        return ci_min, ci_max

def get_confidence_interval(tipo: Literal["lineal", "ensemble", ""] = ""):
    if tipo == "lineal":
        return ConfidenceIntervalLineal()
    elif tipo == "ensemble":
        return ConfidenceIntervalEnsemble()
    else:
        return ConfidenceInterval() 
