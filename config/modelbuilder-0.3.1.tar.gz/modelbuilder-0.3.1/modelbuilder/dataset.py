import copy
import io
from typing import List, Optional
from dataclasses import dataclass

import pandas as pd
import numpy as np

@dataclass
class DatasetColumns:
    """Defined types of columns on a Dataset"""
    keys: List[str]
    features: List[str]
    target: str
    predictions: List[str]
    conf_intervals: List[str]
    errors: List[str]

class Dataset:
    """
    Clase que define un objeto conjunto de datos (pd.Dataframe) para usar por el objeto Model con tipología de columnas:
    | columnas keys | columnas features | columna target | <- Iniciales
    Este objeto se va a usar para entrenar, predecir y validar por lo que se le irán añadiendo otro tipo de columnas:
    | colummnas prediction | columnas confidence interval | columnas errors <- A complementar por el Model

    Attrs:
        data (pd.DataFrame):                                conjunto de datos a explotar por el Model, sin indice
        columns (DatasetColumns):                           clase DatasetColumns con metadata sobre la tipología de columnas
        num_features(int):                                  numero de features en el dataframe
        num_observations(int):                              numero de observaciones en el dataframe
    
    Methods:
        from_column_types (@classmethod)                    permite inicializar un dataset a partir de columnas de tipo keys, features y target
        set_prediction / set_conf_interval / set_error:     setear columnas de tipologia prediction | conf_interval | errors a complementar por el modelo
        get_x / get y:                                      metodos para obtener los datasets filtrados por features (x) o target (y)
        get_subdataset:                                     get a Dataset with the data property filtered by some index                                                          
    """
    def __init__(self, data: pd.DataFrame, columns: DatasetColumns):
        self._data = data
        self.columns = columns
        self.num_features = len(columns.features)
        self.num_observations = self._data.shape[0]

    def __str__(self):
        buf = io.StringIO()
        self.data.info(buf=buf)
        return f"{buf.getvalue()}\n{self.columns.__str__()}"

    @classmethod
    def from_column_types(cls, data: pd.DataFrame, keys: List[str], features: List[str], target: str):
        """
        Inicia un Dataset object a partir de columnas de tipo keys, features y target
        Inicia el dataset solo si existe al menos una feature y una target en el data.
        """
        # Nos quedamos solo con las variables que existan en el dataframe data
        keys = [key for key in keys if key in data.columns]
        features = [feature for feature in features if feature in data.columns]

        # Init
        columns = DatasetColumns(keys, features, target, [], [], [])

        return cls(data, columns)

    @property
    def data(self) -> pd.DataFrame:
        return self._data
    
    @data.setter
    def data(self, dataframe: pd.DataFrame) -> None:
        if isinstance(dataframe, pd.DataFrame):
            self._data = dataframe.reset_index(drop=True)
        else:
            self._data = pd.DataFrame()

    def set_prediction(self, y_pred: pd.DataFrame):
        """Method to set columns of type prediction by Model object"""
        self.columns.predictions.extend(y_pred.columns.to_list())
        self._data = self._data.join(y_pred, how='left', lsuffix="_x")

    def set_conf_interval(self, y_conf_interval: np.ndarray, col_name:str):
        """Method to set column of type conf_interval by Model object"""
        self.columns.conf_intervals.append(col_name)
        self._data[col_name] = y_conf_interval

    def set_error(self, y_err: np.ndarray, col_name:str):
        """Method to set column of type error by Model object"""
        self.columns.errors.append(col_name)
        self._data[col_name] = y_err

    def get_x(self) -> pd.DataFrame:
        """Get X dataframe with only features columns"""
        return self._data[self.columns.features]

    def get_y(self) -> pd.Series:
        """Get Y series with only target column"""
        return self._data[self.columns.target]

    def get_subdataset(self, idx_filter: Optional[List[int]] = None):
        """Get a dataset object with the attr data filtered by some index list"""
        if idx_filter:
            subdataframe = self._data.iloc[idx_filter].copy()
        else:
            subdataframe = self._data.copy()
        subdataset_columns = copy.deepcopy(self.columns)
        return Dataset(subdataframe, subdataset_columns)
