from typing import Optional

import pandas as pd
import mlflow.pyfunc
from sklearn.pipeline import Pipeline

from modelbuilder.dataset import Dataset
from modelbuilder.confidence_interval import ConfidenceInterval
from modelbuilder.custom_except import MissingFeaturesError, NotFittedError, DataEntryNotADataset, PipelineValueError, CIValueError


class Model(mlflow.pyfunc.PythonModel):
    """
    Generic Model for a single target regression task with both ensemble or single models.

    Defined by a Sklearn pipeline object, a validation object (sklearn splitter class) and an optional ConfidenceInterval object.

    Attrs:
        name (str):                 nombre del modelo
        pipeline:                   objeto pipeline de sklearn usado para entrenar con metodos fit(), transform() y predict()
        confidence_interval:        objeto confidence_interval con metodos fit() y transform()
        base_error (float)          error base definido para el modelo (puede ser un acc, mae o lo que queramos) en un momento dado

    """

    def __init__(self, name: str, pipeline: Pipeline, 
                 confidence_interval: Optional[ConfidenceInterval] = None):

        self.name = name
        self.pipeline = pipeline
        self.confidence_interval = confidence_interval
        self.dataset: Optional[Dataset] = None
        self._is_fitted: bool = False
        self._is_validated: bool = False

    @property
    def base_error(self) -> float:
        return self._base_error
    
    @base_error.setter
    def base_error(self, base_error: float):
        self._is_validated = True
        self._base_error = base_error

    def fit(self, dataset: Dataset):
        """
        Fit method to train the model.
        """
        # Set Model data and get train_x and train_y
        self.dataset = dataset.get_subdataset()
        train_x, train_y = self.dataset.get_x(), self.dataset.get_y()
        
        # Run fit
        self.pipeline.fit(train_x, train_y)

        # Añadir predicciones de train con el append "train"
        train_pred = self._pipeline_predict(train_x)
        train_pred.columns = [f"{col}_train" for col in train_pred.columns]
        self.dataset.set_prediction(train_pred)

        # Si existe un objeto CI, entrenarlo
        if self.confidence_interval:
            self.confidence_interval.fit(self.dataset)
        
        # Entrenamiento completado
        self._is_fitted = True
    
    def _pipeline_predict(self, data: pd.DataFrame)-> pd.DataFrame:
        # Usamos metodo predict de la pipeline
        pred = self.pipeline.predict(data)
        pred = pd.DataFrame({"prediction":pred}, index=data.index)
        try:
            # Si la pipeline tiene metodo transform (ENSEMBLE), añade las i predicciones unitarias prediction_i
            ensemble_preds = self.pipeline.transform(data)
            for i in range(ensemble_preds.shape[1]):
                pred[f"prediction_{i}"] = ensemble_preds[:,i]
        except:
            pass
        return pred
            
    def predict(self, context, model_input: Dataset) -> Dataset:
        """
        Infer data on fitted model. Method used in API calls.

        Parameters:
            context (MLflow API context):       MLflow API context
            model_input (Dataset):              input data to perform predictions
        """
        if self._is_fitted and self.dataset:
          
            if isinstance(model_input, Dataset):
                try:
                    # Select trained features
                    model_input_x = model_input.data[self.dataset.columns.features]
                except KeyError:
                    raise MissingFeaturesError("Model input has not all features used in train")

                # Prediction of pipeline and add to model_input
                try:
                    pred = self._pipeline_predict(model_input_x)
                except ValueError:
                    raise PipelineValueError("Prediction pipeline received invalid input values")
                model_input.set_prediction(pred)

                # Prediction of confidence interval and add to model_input
                if self.confidence_interval and self._is_validated:
                    try:
                        ci_min, ci_max = self.confidence_interval.transform(model_input, self._base_error)
                    except ValueError:
                        raise CIValueError("Confidence interval received invalid input values")
                    model_input.set_conf_interval(ci_min, "ci_min")
                    model_input.set_conf_interval(ci_max, "ci_max")
                    
                return model_input
            else:
                raise DataEntryNotADataset("Data entry is not a Dataset instance")
        else:
            raise NotFittedError("This model is not fitted yet. Call 'fit' method")

    def get_params(self):
        try:
            params = self.pipeline.named_steps["predictor"].get_params()
        except:
            params = {}

        return params

    def get_tags(self):
        try:
            tags = {"model_name": self.name,
                    "target": self.dataset.columns.target,
                    "features" : " & ".join(self.dataset.columns.features)[:5000]}
        except:
            tags = {}
        
        return tags

