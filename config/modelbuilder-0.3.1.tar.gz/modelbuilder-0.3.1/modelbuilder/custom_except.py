# EXCEPTIONS FOR MODEL PREDICTION

class NotFittedError(Exception):
    pass

class MissingFeaturesError(Exception):
    pass

class DataEntryNotADataset(Exception):
    pass

class PipelineValueError(Exception):
    pass

class CIValueError(Exception):
    pass
