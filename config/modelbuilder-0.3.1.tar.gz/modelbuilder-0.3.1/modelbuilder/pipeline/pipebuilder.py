######## HEADER TO CONFIGURE LOGS ########
import logging
log = logging.getLogger(__name__)
##########################################

from typing import Literal, Optional

from sklearn.impute import KNNImputer, SimpleImputer
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.svm import SVR
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor, VotingRegressor


PipelineName = Literal["LR", "RIDGE", "SVR", "GB", "RF", "ENSEMBLE_SVR_GB", "ENSEMBLE_RIDGE_GB", "ENSEMBLE_RF_GB"]


def get_pipeline(pipeline_name: PipelineName, predictor_params: Optional[dict] = None) -> Pipeline:
    """
    predictor_params: init parameters passed to the predictor step of the pipeline
    """
    if predictor_params is None:
        predictor_params = {}
    if pipeline_name == "LR":
        return _build_linear_regression(predictor_params)
    elif pipeline_name == "RIDGE":
        return _build_ridge(predictor_params)    
    elif pipeline_name == "SVR":
        return _build_svr(predictor_params)
    elif pipeline_name == "GB":
        return _build_gb(predictor_params)
    elif pipeline_name == "RF":
        return _build_rf(predictor_params)    
    elif pipeline_name == "ENSEMBLE_SVR_GB":
        return _build_ensemble_svr_gb(predictor_params)
    elif pipeline_name == "ENSEMBLE_RIDGE_GB":
        return _build_ensemble_ridge_gb(predictor_params)
    elif pipeline_name == "ENSEMBLE_RF_GB":
        return _build_ensemble_rf_gb(predictor_params)
    else:
        log.warning("Tipo de pipeline no reconocido. Generando pipeline estándar (LR)...")
        return _build_linear_regression(predictor_params)    


def _build_linear_regression(predictor_params: dict) -> Pipeline:
    scaler = MinMaxScaler()           
    predictor = LinearRegression(**predictor_params)
    pipeline = Pipeline([("scaler", scaler), ("predictor", predictor)])
    return pipeline


def _build_svr(predictor_params: dict) -> Pipeline:
    scaler = StandardScaler()
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    predictor = SVR(**predictor_params)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline


def _build_gb(predictor_params: dict) -> Pipeline:
    scaler = StandardScaler() # GB no lo necesita
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    predictor = GradientBoostingRegressor(**predictor_params)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline


def _build_rf(predictor_params: dict) -> Pipeline:
    scaler = StandardScaler() # RF no lo necesita
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    predictor = RandomForestRegressor(**predictor_params)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline


def _build_ridge(predictor_params: dict) -> Pipeline:
    scaler = StandardScaler()
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    predictor = Ridge(**predictor_params)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline


def _build_ensemble_svr_gb(predictor_params: dict) -> Pipeline:
    """
    predictor_params:   Each regressor is prefixed such that parameter p for step s has key s__p.
                        {"SVR__epsilon": 0.025, "GB__n_estimators":100}
    """
    predictor_params_SVR = {k[5:]:v for k,v in predictor_params.items() if k[:5]=="SVR__"}
    predictor_params_GB = {k[4:]:v for k,v in predictor_params.items() if k[:4]=="GB__"}

    scaler = StandardScaler()
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    ensemble_models = [("SVR", SVR(**predictor_params_SVR)), ("GB", GradientBoostingRegressor(**predictor_params_GB))]
    predictor = VotingRegressor(ensemble_models)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline


def _build_ensemble_ridge_gb(predictor_params: dict) -> Pipeline:
    """
    predictor_params:   Each regressor is prefixed such that parameter p for step s has key s__p.
                        {"RIDGE__alpha": 10.0, "GB__n_estimators":100}
    """    
    predictor_params_RIDGE = {k[7:]:v for k,v in predictor_params.items() if k[:7]=="RIDGE__"}
    predictor_params_GB = {k[4:]:v for k,v in predictor_params.items() if k[:4]=="GB__"}

    scaler = StandardScaler()
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    ensemble_models = [("RIDGE", Ridge(**predictor_params_RIDGE)), ("GB", GradientBoostingRegressor(**predictor_params_GB))]
    predictor = VotingRegressor(ensemble_models)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline


def _build_ensemble_rf_gb(predictor_params: dict) -> Pipeline:
    """
    predictor_params:   Each regressor is prefixed such that parameter p for step s has key s__p.
                        {"RF__max_features": 0.5, "GB__n_estimators":100}
    """
    predictor_params_RF = {k[4:]:v for k,v in predictor_params.items() if k[:4]=="RF__"}
    predictor_params_GB = {k[4:]:v for k,v in predictor_params.items() if k[:4]=="GB__"}

    scaler = StandardScaler()
    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    ensemble_models = [("RF", RandomForestRegressor(**predictor_params_RF)), ("GB", GradientBoostingRegressor(**predictor_params_GB))]
    predictor = VotingRegressor(ensemble_models)
    pipeline = Pipeline([("scaler", scaler), ("imputer", imputer), ("predictor", predictor)])
    return pipeline