import copy
from typing import List

import numpy as np
import pandas as pd
from sklearn.model_selection._split import _BaseKFold, KFold

from modelbuilder.dataset import Dataset
from modelbuilder.model import Model

def validate(model: Model, dataset:Dataset, splitter: _BaseKFold = KFold(5)) -> Dataset:
    model = copy.deepcopy(model)

    valid_dataset_list: List[Dataset] = []
    for train, test in splitter.split(dataset.data):

        # Get train, valid data
        train_dataset = dataset.get_subdataset(list(train))
        test_dataset = dataset.get_subdataset(list(test))

        # Fit model
        model.fit(train_dataset)
        
        # Predict and append
        valid_dataset_i = model.predict(context=None, model_input=test_dataset)
        valid_dataset_list.append(valid_dataset_i)

    data_concat = pd.concat([dataset_i.data for dataset_i in valid_dataset_list]).sort_index()
    dataset = Dataset(data=data_concat, columns=valid_dataset_i.columns)

    return dataset

def regression_metrics(dataset: Dataset) -> Dataset:
    """
    Computes metrics in order to validate a model.
    """
    target = dataset.columns.target
    predictions = dataset.columns.predictions

    for prediction in predictions:
        # Get metrics
        dataset.set_error(dataset.data[target] - dataset.data[prediction], f"err_{prediction}")
        dataset.set_error(np.abs(dataset.data[target] - dataset.data[prediction]), f"abs_err_{prediction}")
        dataset.set_error(100 * (dataset.data[f"abs_err_{prediction}"]/dataset.data[target]), f"perc_err_{prediction}")
    
    return dataset

def get_metrics(dataset: Dataset) -> dict:
    """
    Extracts metrics (MAE, MAPE & 95% percentile) from error columns of a Dataset as a dictionary.
    """
    errors = dataset.columns.errors
    metrics_mean = pd.Series(dataset.data[errors].mean().round(3).values, index=[f"{c}_mean" for c in errors])
    metrics_median = pd.Series(dataset.data[errors].median().round(3).values, index=[f"{c}_median" for c in errors])
    metrics_q95 = pd.Series(dataset.data[errors].quantile(0.95).round(3).values, index=[f"{c}_q95" for c in errors])
    num_observations = dataset.data.shape[0]
    num_features = len(dataset.columns.features)
    metrics = {**metrics_mean, **metrics_median, **metrics_q95, 'num_observations':num_observations, 'num_features':num_features}
    return metrics


def build_metrics(model: Model, dataset:Dataset, splitter: _BaseKFold = KFold(5)) -> dict:
    """
    Validates a model, calculate regression metrics and extract them as a dictionary.
    """
    dataset_validate = validate(model, dataset, splitter)
    regression_metrics(dataset_validate)
    metrics = get_metrics(dataset_validate)
    return metrics