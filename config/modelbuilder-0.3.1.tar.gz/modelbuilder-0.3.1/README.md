# model-builder

Librería para construcción de modelos de ML usando pipelines de sklearn y herramientas de código para el estudio analítico

```
Release Version: 0.3.1
```

## Estructura

```
├── modelbuilder
│   ├── pipeline
│   │   ├── __init__.py
│   │   └── pipebuilder.py
│   ├── validation
│   │   ├── __init__.py
│   │   └── validate.py
│   ├── __init__.py
│   ├── confidence_interval.py
│   ├── custom_except.py
│   ├── dataset.py
│   ├── model.py
│   └── version.py
├── Dockerfile_artifact_publish
├── README.md
├── requirements.txt
├── sa_ar_writer.json
├── setup.py
└── test.py
```
# Operaciones

## Publicación de nueva versión en Google Artifact Registry

Con cada Pull Request a main, debe publicarse en Google Artifact Registry la librería actualizada (es necesario incrementar la versión).

```
$ docker build -f Dockerfile_artifact_publish .
```

## Instalación de librería desde Google Artifact Registry

Debe disponerse de acceso al repositorio en Google Artifact Registry y facilitarle su URL a pip, bien por línea de comandos bien por un archivo de configuración.

Para utilizarlo en un contenedor Docker, incorporar al Dockerfile estas líneas:

```
# Configure PIP to use Google Artifact Registry
COPY config/envs/pip.conf /etc/pip.conf

# Install libraries from Artifact registry
RUN pip install modelbuilder
```

---

### Changelog

#### v0.3.1

KNNImputer por SimpleImputer en pipelines predefinidas.

#### v0.3

Nuevas pipelines predefinidas para modelos Ridge y RandomForest (individuales y ensemble).

#### v0.2

Métricas y fixes menores.

#### v0.1

Inicializar librería con la refactorización del constructor de modelos.